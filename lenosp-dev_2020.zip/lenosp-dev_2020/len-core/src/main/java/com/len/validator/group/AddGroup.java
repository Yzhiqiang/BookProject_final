package com.len.validator.group;

/**
 * 
 * @ClassName: AddGroup   
 * @Description: 新增数据 Group
 * @author: liutao
 * @date: 2018年3月16日 下午12:15:23
 */
public interface AddGroup {
}
