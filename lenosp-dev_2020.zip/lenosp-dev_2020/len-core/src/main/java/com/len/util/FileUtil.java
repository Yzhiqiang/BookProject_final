package com.len.util;

/**
 * @author zxm
 * @date 2021/3/26 21:38
 * <p>
 * 文件操作
 */


public class FileUtil {


    public static final String defaultPhoto = "default.jpg";


}
