package com.len.mapper;

import com.len.base.BaseMapper;
import com.len.entity.SysJob;

public interface SysJobMapper extends BaseMapper<SysJob> {
}