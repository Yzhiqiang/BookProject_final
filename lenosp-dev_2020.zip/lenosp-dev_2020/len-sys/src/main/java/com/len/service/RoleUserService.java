package com.len.service;

import com.len.base.BaseService;
import com.len.entity.SysRoleUser;
import java.util.List;

/**
 * @author zhuxiaomeng
 * @date 2017/12/21.
 * @email lenospmiller@gmail.com
 */
public interface RoleUserService  extends BaseService<SysRoleUser,String>{
}
