package com.len.mapper;

import com.len.base.BaseMapper;
import com.len.entity.SysDepart;

public interface SysDepartMapper extends BaseMapper<SysDepart> {
}