package com.len.mapper;

import com.len.base.BaseMapper;
import com.len.entity.SysUserDepart;

public interface SysUserDepartMapper extends BaseMapper<SysUserDepart> {
}