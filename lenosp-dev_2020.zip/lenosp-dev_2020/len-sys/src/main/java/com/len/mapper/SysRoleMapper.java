package com.len.mapper;

import com.len.base.BaseMapper;
import com.len.entity.SysRole;

public interface SysRoleMapper extends BaseMapper<SysRole> {
}