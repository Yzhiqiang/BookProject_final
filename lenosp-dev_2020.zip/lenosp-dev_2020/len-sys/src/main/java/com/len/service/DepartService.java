package com.len.service;

import com.len.base.BaseService;
import com.len.entity.SysDepart;

public interface DepartService extends BaseService<SysDepart, String> {
}
