package com.len.mapper;

import com.len.base.BaseMapper;
import com.len.entity.SysLog;

public interface SysLogMapper extends BaseMapper<SysLog> {
}