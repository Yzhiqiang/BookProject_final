package com.len.mapper;

import com.len.base.BaseMapper;
import com.len.entity.ArticleTag;

public interface ArticleTagMapper extends BaseMapper<ArticleTag> {
}