package com.len.service;

import com.len.base.BaseService;
import com.len.entity.BlogCategory;

/**
 * @author zhuxiaomeng
 * @date 2018/7/22.
 * @email lenospmiller@gmail.com
 */
public interface BlogCategoryService extends BaseService<BlogCategory, String> {
}
