package com.len.mapper;

import com.len.base.BaseMapper;
import com.len.entity.BlogCategory;

public interface BlogCategoryMapper extends BaseMapper<BlogCategory> {
}