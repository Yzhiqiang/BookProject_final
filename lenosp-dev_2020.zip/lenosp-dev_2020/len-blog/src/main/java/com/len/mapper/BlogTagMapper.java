package com.len.mapper;

import com.len.base.BaseMapper;
import com.len.entity.BlogTag;

public interface BlogTagMapper extends BaseMapper<BlogTag> {
}