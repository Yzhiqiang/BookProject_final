package com.len.service;

import com.len.base.BaseService;
import com.len.entity.ArticleTag;

/**
 * @author zhuxiaomeng
 * @date 2018/11/19.
 * @email lenospmiller@gmail.com
 */
public interface ArticleTagService extends BaseService<ArticleTag, String> {
}
