package com.len.service;

import com.len.base.BaseService;
import com.len.entity.BlogTag;

/**
 * @author zhuxiaomeng
 * @date 2018/7/28.
 * @email lenospmiller@gmail.com
 */
public interface BlogTagService extends BaseService<BlogTag,String> {
}
